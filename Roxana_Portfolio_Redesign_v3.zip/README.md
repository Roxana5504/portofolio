# Roxana Cenușă — Portfolio (redesign, v3)

Website static, responsive, în limba engleză, gata de publicare.

## Conținut
- `index.html` — conținutul paginii și cele 10 prezentări de proiecte;
- `styles.css` — design, culori, layout desktop/tabletă/mobil;
- `script.js` — filtrele portofoliului, ferestrele de detalii și meniul mobil;
- `assets/` — portret, ilustrații și favicon.

## Publicare rapidă
1. Accesează https://app.netlify.com/drop
2. Încarcă arhiva ZIP sau folderul extras. Dacă platforma îți cere, extrage ZIP-ul și încarcă folderul ce conține `index.html`.
3. Copiază linkul public `*.netlify.app` primit după publicare.

Pentru actualizări la aceeași adresă: intră în site-ul tău din Netlify, secțiunea **Deploys**, apoi încarcă o nouă versiune a folderului.

Alternativ, poți publica același folder pe Vercel sau orice hosting static.

## Modificări ulterioare
- Descrierile scurte: `index.html`, în secțiunea `.project-grid`.
- Detaliile din popup: `script.js` -> `projectData`.
- Culori: primele variabile din `styles.css` (`--pink`, `--ink`, `--paper`).
- Linkuri social: în secțiunea `#contact` din `index.html`.

Nu au fost introduse procente sau rezultate de campanii neconfirmate. Imaginile proiectelor sunt ilustrații editoriale, nu screenshot-uri ale conturilor publicitare.
